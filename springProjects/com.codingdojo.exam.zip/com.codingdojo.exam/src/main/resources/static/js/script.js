var votes = document.querySelectorAll(".vote");
if(votes){
	
}